# test/__main__.py

import unittest

from .stock import *
from .dateobj import *

if __name__ == '__main__':
    unittest.main()
